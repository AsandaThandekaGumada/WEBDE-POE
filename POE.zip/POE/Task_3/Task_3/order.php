<?php
    session_start();
    include 'DBConn.php';    
?>
<?php 
    if(isset($_GET['action']))
    {

    }

?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shopping Cart</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    
    <link rel="stylesheet" href="cart.css">

 
</head>
<body>
<div class = "topnav">
         <a  href="cart.php" >Show Cart</a>
         <a  href="MyShop.php" >View Store</a>
         <a href="logout.php">Logout</a>
         <a href="Add Item.php">Panel</a>
    </div>
<div >
       <h1><?php  
                echo '<h1>Welcome Back - '.$_SESSION["user"].'.View Your Customer Orders Here.</h1>';  
                ?> </h1>
                </br>
                
                </div>
        </br>
        </br>
        </br>
<?php if(isset($_GET['action']) && $_GET['action']=='order' && $_GET['Customer_ID'])
{ ?>

    <div class="container mt-5">


    <h6><?php //echo ?></h6>
    <div class="row">
    <a href="order.php" class="btn btn-">Back</a>
    <table>
        <thead>
            <tr>

            <th>Customer ID</th>
            <th>ID</th>
            <th>Order ID</th>
            <th>Product Name</th>
            <th>Product Price</th>
            <th>Product Quantity</th>

            </tr>
        </thead>
        <?php

            $sql = "SELECT * FROM `tbl_order` inner join tbl_Customer on 
            `tbl_order.Customer_ID` = `tbl_Customer.Customer_ID`
            inner join tbl_item on 
            `tbl_order.itemID` = `tbl_item.itemID`
            WHERE Order_ID =".$_GET['Customer_ID']."";
            $result = $conn->query($sql);
            if($result->num_rows >0)
            {
                while (($row = mysqli_fetch_assoc($result))) {
                    $id =$row['Customer_ID'];
                    $Order_ID= $row['Order_ID'];
                    $Product_Name= $row['Description'];
                    $Product_Price= $row['Sell Cost'];
                    $Product_Qty =$row['Quantity']; ?>
                     <tbody>
                            <tr>
                            <td><?php echo $id; ?></td>
                            <td><?php echo $Order_ID; ?></td>
                            <td><?php echo $Product_Name; ?></td>
                            <td><?php echo $Product_Price; ?></td>
                            <td><?php echo $Product_Qty; ?></td>
                            <td><a herf ="?action=order&id=<?php echo $id ?>" class="btn btn-sm btn-info" 
                            style ="width: 120px;">View Order</a></td>
            </div>
                            </tr>
                            </tbody>
                            <?php
                }

                    
            }

        ?>

    </table>


    </div>

</div>



        <div class ="container"> 
        <form method="POST" class="text-white" enctype ="multipart/form-data">

        <div class ="row">

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Firsttname</th>
                        <th>Lastname</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>Zip code</th>
                        <th>COntact No.</th>
                        <th class = "test-center" >Action</th>

                    
                    </tr>

                </thead>
                <?php
                $sql = "SELECT * FROM `tbl_user` inner join tbl_Customer on 'tbl_Customer.ID' = 'tbl_user.ID'";
                    $result = $conn->query($sql);
                    if (($result->num_rows) >0) {
                        while (($row = mysqli_fetch_assoc($result))) {
                            $id =$row['Customer_ID'];
                            $name= $row['FName'];
                            $l_name= $row['LName'];
                            $Add= $row['Address'];
                            $email =$row['Email'];
                            $con = $row['Contact_num']; ?>
                             <tbody>
                            <tr>
                            <td><?php echo $id; ?></td>
                            <td><?php echo $name; ?></td>
                            <td><?php echo $l_name; ?></td>
                            <td><?php echo $Add; ?></td>
                            <td><?php echo $email; ?></td>
                            <td><?php echo $con; ?></td>
                            <td><a herf ="?action=order&id=<?php echo $id ?>" class="btn btn-sm btn-info" 
                            style ="width: 120px;">View Order</a></td>
            </div>
                            </tr>
                            </tbody>
                <?php
                        }
                    } ?>
           
             </table>
        
</div>

    


</body>
</html>
<?php
}?>