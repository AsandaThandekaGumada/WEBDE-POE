-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2021 at 08:33 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'Asanda', 'tagumada@mail.com', '2468100');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `itemID` text NOT NULL,
  `image` varchar(225) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `itemID`, `image`) VALUES
(1, 'CANT5', '13661-cantu-scalp-treatment-180ml.jpg'),
(2, 'ANTI1', 'AuntJackie\'s PerfectType4Kit.jpg'),
(3, 'NATC4', 'NativeChildAntibreakage&Transitioningcombo.jpg'),
(4, 'NATC1', 'NativeChild-KidsStartercombo.jpg'),
(5, 'NATC2', 'NativeChild-LOCcombo.jpg'),
(6, 'NATC3', 'Native Child - Shampoo and Conditioner combo.jpg'),
(7, 'CANT1 ', 'cantu-curl-activator-cream-355ml-13459663814713_202x.jpg'),
(8, 'CANT2', 'cantu-edge-stay-gel-64g-13610225696825_202x.jpg'),
(9, 'CANT3', 'cantu-grow-strong-173g-13459659685945_202x.jpg'),
(10, 'CANT4', 'cantu-repair-cream-shea-butter-453g-13511271022649_202x.jpg'),
(11, 'CANT6', 'cantu-strengthening-styling-gel-524g-13459664666681_202x.jpg'),
(12, 'ANTI3', 'aunt-jackie-s-perfect-911-damage-repair-kit-28758267363478_2048x2048.jpg'),
(13, 'ANTI4', 'aunt-jackie-s-perfect-intense-define-bundle-28758192816278_2048x2048.jpg'),
(14, 'ANTI5', 'aunt-jackie-s-perfect-hydrate-your-curls-kit-large-28758572826774_2048x2048.jpg'),
(15, 'ANTI6', 'aunt-jackie-s-perfect-wash-n-go-kit-28758389358742_2048x2048.jpg'),
(16, 'SHEA1', 'NaturalDirectSheaButter.jpg'),
(17, 'HAIRK', 'CurlyCareNaturaHairProductsStarterKit.jpg'),
(18, 'CROCH', '741-crochet-needle-18876604055702_202x.jpg'),
(19, 'DARL2', '2231-1-darling-one-million-braid-20-13376284164153_216x.jpg'),
(20, 'DARL1', '15480-1-darling-passion-twist-30-19009231421590_216x.jpg'),
(21, 'DARL3', '14521-1-darling-marley-kinky-braid-14-20086467428502_216x.jpg'),
(22, 'DARL4', '14209-darling-one-million-braid-20-1-value-pack-20086330884246_216x.jpg'),
(23, 'DARL5', '16258-darling-pre-curled-braid-19-1-28191906431126_216x.jpg'),
(24, 'AFRO1', '13216-afrotex-afro-classic-16-1-13439910281273_216x.jpg'),
(25, 'AFRO2', '16312-1-afrotex-yaky-braid-24-value-pack-28192529842326_216x.jpg'),
(26, 'AFRO3', '14452-hair-nova-afro-phondo-1-large-27970357854358_216x.jpg'),
(27, 'AFRO4', '10636-afrotex-eazy-braid-27-1-27-19929914900630_216x.jpg'),
(28, 'BEAU1', '13421-beau-diva-straight-8-10-12-natural-13383893745721_216x.jpg'),
(29, 'BEAU2', '13423-beau-diva-straight-12-14-16-natural-19931448213654_216x.jpg'),
(30, 'BEAU3', '13424-beau-diva-straight-14-16-18-natural-19931472953494_216x.jpg'),
(32, 'qwerq', 'images/Logo.png'),
(33, 'qwerq', 'images/Logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `Customer_ID` int(10) NOT NULL,
  `ID` int(11) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Contact_num` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`Customer_ID`, `ID`, `Address`, `Contact_num`) VALUES
(1, 1, '4 Arend Street', 535684123),
(2, 2, '5 Arend Street', 2147483647),
(3, 3, '10 Sebe Street', 536987456),
(4, 4, '78 Rochesll Street', 2147483647),
(5, 6, 'AJ Street 45 ', 2147483647),
(6, 7, 'Kenasi Street 74', 1247856953),
(7, 8, '5878 Rondabult Roodekop', 564789999),
(8, 9, '45 Amanda Street', 2147483647),
(9, 10, '785 Queenstown Street', 2147483647),
(10, 11, 'Namane 125 Street', 870874521),
(11, 12, ' 789 Kercia Street Rondabult', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_item`
--

CREATE TABLE `tbl_item` (
  `itemID` text NOT NULL,
  `Description` text NOT NULL,
  `Cost Price` decimal(10,0) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Sell Price` decimal(10,0) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_item`
--

INSERT INTO `tbl_item` (`itemID`, `Description`, `Cost Price`, `Quantity`, `Sell Price`) VALUES
('ANTI1', 'Aunt Jackie\'s Perfect Type 4 Kit', '266', 100, '326'),
('NATC4', 'Native Child - Anti breakage & Transitioning combo', '289', 369, '350'),
('NATC1', 'Native Child - Kids Starter Combo', '250', 51, '310'),
('NATC2', 'Native Child - LOC Combo', '150', 20, '210'),
('NATC3', 'Native Child - Shampoo and Conditioner Combo', '100', 9, '160'),
('CANT1', 'Cantu Curl Activator Cream', '50', 150, '90'),
('CANT2', 'Cantu Edge Stay Gel', '77', 53, '104'),
('CANT3', 'Cantu Grow Strong', '85', 20, '126'),
('CANT4', 'Cantu Repair Cream Shea Butter', '66', 101, '126'),
('CANT6', 'Cantu Strengthening Styling gel', '91', 21, '181'),
('ANTI3 ', 'Aunt Jackie\'s Perfect 911 Damage Repair Kit', '420', 33, '470'),
('ANTI4 ', 'Aunt Jackie\'s Perfect Intense Define Bundle', '307', 50, '367'),
('ANTI5 ', 'Aunt Jackie\'s Perfect Hydrate Your Curls Kit Large', '300', 100, '360'),
('ANTI6', 'Aunt Jackie\'s Perfect Wash n’ Go Kit', '220', 132, '280'),
('CANT5', 'Cantu Scalp Treament', '200', 200, '260'),
('SHEA1', 'Nature Direct Shea Butter 1Kg', '275', 150, '300'),
('HAIRK', 'Curly Care - Natural Hair Products - StarterKit', '620', 50, '650'),
('CROCH', 'Crochet Braid Needle', '10', 500, '16'),
('DARL1', 'DARLING HAIR PIECES Darling Passion Twist', '30', 90, '150'),
('DARL2', 'DARLING HAIR PIECES Darling One Million Braid 20', '25', 10, '26'),
('DARL3', 'Darling Marley Kinky Braid 14', '60', 150, '65'),
('DARL4', 'HAIR PIECES Darling One Million Braid 20', '50', 50, '51'),
('DARL5', 'Darling Pre-Curled Braid 19\" #1', '210', 120, '220'),
('AFRO1', 'Afrotex Afro Classic 16', '76', 35, '80'),
('AFRO2', 'Afrotex Yaky Braid 24\" Value Pack', '24', 50, '30'),
('AFRO3', ' AFRO3,Hair Nova Afro Phondo #1 Large', '95', 56, '100'),
('AFRO4', 'Afrotex Eazy Braid 27\" Ombre', '21', 0, '30'),
('BEAU1', 'Beau Diva Straight 8\"+10\"+12\" #Natural', '495', 1000, '500'),
('BEAU2', 'Beau Diva Straight 12\"+14\"+16\" #Natural', '780', 150, '800'),
('BEAU3', 'Beau Diva Straight 14\"+16\"+18\" #Natural', '950', 100, '1000'),
('', '', '0', 0, '0'),
('qwerq', 'asdes', '250', 5, '654');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `Order_ID` int(10) NOT NULL,
  `Customer_ID` int(11) NOT NULL,
  `itemID` varchar(5) NOT NULL,
  `Delivery Price` decimal(10,0) NOT NULL,
  `Total_Price` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `ID` int(11) NOT NULL,
  `FName` text NOT NULL,
  `LName` text NOT NULL,
  `Email` text NOT NULL,
  `Password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`ID`, `FName`, `LName`, `Email`, `Password`) VALUES
(1, 'asa', 'a', 'a@mail.com', '457391c9c82bfdcbb4947278c0401e41'),
(2, 'Zelrease', 'Josef', 'ZK@mail.com', '457391c9c82bfdcbb4947278c0401e41'),
(3, '1', '1', '1@mal.com', '457391c9c82bfdcbb4947278c0401e41'),
(4, 'q', 'q', 'q@mail.com', '457391c9c82bfdcbb4947278c0401e41'),
(5, '0', '0', '0@mai.com', '457391c9c82bfdcbb4947278c0401e41'),
(6, '5', 'l', 'l@l.com', '457391c9c82bfdcbb4947278c0401e41'),
(7, 'q', 'q', 'q@q.com', '457391c9c82bfdcbb4947278c0401e41'),
(8, 't', 't', 't@t.com', '457391c9c82bfdcbb4947278c0401e41'),
(9, 'p', 'p', 'p@p.com', '457391c9c82bfdcbb4947278c0401e41'),
(10, 'e', 'r', 'e@e.cm', '457391c9c82bfdcbb4947278c0401e41'),
(11, 'w', 'w', 'w@w.com', '457391c9c82bfdcbb4947278c0401e41'),
(12, 'lala', 'la', 'lala@mail.com', '457391c9c82bfdcbb4947278c0401e41'),
(13, 'lala', 'la', 'lala@mail.com', '457391c9c82bfdcbb4947278c0401e41'),
(14, 'lala', 'la', 'lala@mail.com', '457391c9c82bfdcbb4947278c0401e41'),
(15, 'k', 'k', 'k@k.com', '457391c9c82bfdcbb4947278c0401e41'),
(16, 'j', 'j', 'j@j.com', '457391c9c82bfdcbb4947278c0401e41'),
(17, 'f', 'f', 'f@f.com', '457391c9c82bfdcbb4947278c0401e41'),
(18, 'p', 'p', 'p@mail.com', '457391c9c82bfdcbb4947278c0401e41'),
(19, 'asa', 'asa', 'asa@mail.com', '457391c9c82bfdcbb4947278c0401e41'),
(20, 'Lungile', 'Gumada', 'lg@mail.com', '457391c9c82bfdcbb4947278c0401e41'),
(21, 'q', 'q', 'q@m.com', '457391c9c82bfdcbb4947278c0401e41'),
(22, 'Asa', 'Asa', 'Asa@mail.com', '457391c9c82bfdcbb4947278c0401e41'),
(23, '', '', '', '457391c9c82bfdcbb4947278c0401e41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `tbl_item`
--
ALTER TABLE `tbl_item`
  ADD PRIMARY KEY (`itemID`(5));

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`Order_ID`),
  ADD KEY `Customer_ID` (`Customer_ID`,`itemID`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `Customer_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `Order_ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD CONSTRAINT `tbl_order_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `tbl_customer` (`Customer_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
