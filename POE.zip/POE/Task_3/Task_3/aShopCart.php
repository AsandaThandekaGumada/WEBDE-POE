<?php
class ShoppingCart
{
   
        private $conn = NULL;
        private $tbl_item = array();
        private $shoppingCart= array();
        // class constructor
        function __construct()
        {
            include("DBConn.php");
            $this->conn = $conn;
        }
        
        function __destruct()
        {
            if(!$this->conn_error)
            $this->conn->close();
        }

        function __wakeup()
        {
            include("DBConn.php");
            $this->conn = $conn;
        }
       
    
    public function getShop()
    {
        $sql = "select * from tbl_item inner join products on tbl_item.itemID = products.itemID";
        $result = mysqli_query($this->conn, $sql);

        if(mysqli_num_rows($result) > 0)
        {
            return $result;
        }

    }


    public function cart($total, $value)
    {
        $element = "<tr>
                 <td><?php echo". $value["item_name"]." ?></td>
                    <td><?php echo ".$value["item_quantity"]." ?></td>
                    <td>R <?php echo ".$value["product_price"]." ?></td>
                    <td>
                        R <?php echo number_format(".$value["item_quantity"] ."*". $value["product_price"].", 2); ?></td>
                    <td><a href=\"index.php?action=delete&id=<?php ". $value["product_id"]." ?>\"><span
                                class=\"text-danger\">Remove Item</span></a></td>

                </tr>
                <?php
                $total = $total + (".$value["item_quantity"]. "* ".$value["product_price"].");
            }
                ?>
                <tr>
                    <td colspan=\"3\" align=\"right\">Total</td>
                    <th align=\"right\">R <?php echo number_format($total, 2); ?></th>
                    <td></td>
                </tr>
                <?php
            }";
     echo $element;
    }

    private function addItem()
    {
        $ProdID = $_GET['add'];
        if(array_key_exists($ProdID, $this->shoppingCart))
        {
            $this->shoppingCart[$ProdID] +=1;
        }
    }
    private function removeItem()
    {
        $ProdID = $_GET['delete'];
        if(array_key_exists($ProdID, $this->shoppingCart))
            if($this->shoppingCart[$ProdID]>0)
            $this->shoppingCart[$ProdID] -=1;
    }
    private function emptyCart()
    {
        foreach($this->shoppingCart as $key => $values)
        $this->shoppingCart[$key];
    }
    public function checkout()
    {
        $ProductOrdered = 0;
        foreach($this->shoppingCart as $productID => $quantity)
        {
            if($quantity > 0)
            {
                ++$ProductOrdered;
                $sql = "INSERT INTO tbl_order"
                . "Order_ID, itemID, Delivery Price, Total_Price"
                ."VALUES('". session_id() . "', ". "'$productID'
                . $quantity)";
                $result = $this->conn->query($sql);

            }
            return $result;
        }
        echo "<p><strong>Your order has been recorded.</strong></p>\n";

    }

       
}

?>