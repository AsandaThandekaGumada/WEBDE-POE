<?php
    session_start();
    include 'DBConn.php';    
?>

<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shopping Cart</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    
    <link rel="stylesheet" href="cart.css">

 
</head>
<body>
<div class = "topnav">
         <a  href="cart.php" name="shopping_cart" class="active" data-toggle="popover" data-placement="top">Show Cart</a>
         <a  href="MyShop.php" name="shopping_cart" class="active" data-toggle="popover" data-placement="top">View Store</a>
         <a href="logout.php">Logout</a>
         <a href="order.php">View Orderes</a>
    </div>
<div >
       <h1><?php  
                echo '<h1>Welcome Back - '.$_SESSION["user"].'. Load Your Items Below.</h1>';  
                ?> </h1>
                </br>
                
                </div>
        </br>
        </br>
        </br>
        <div class ="container"> 
        <form method="POST" class="text-white" enctype ="multipart/form-data">

        <div class ="row">
        <div class="form-group col-md-6">
            <label>Product Code</label>
            <input type="text" name="p_code" class ="form-control form-control-sm">
            </div>
            <div class="form-group col-md-6">
            
            <label>Product Description</label>
            <input type="text" name="p_name" class ="form-control form-control-sm">
            </div>
            <div class="form-group col-md-6">
            <label>Product Cost Price R</label>
            <input type="text" name="p_cost" class ="form-control form-control-sm">
            </div>
            <div class="form-group col-md-6">
            <label>Product Price R</label>
            <input type="text" name="p_price" class ="form-control form-control-sm">
            </div>
            <div class="form-group col-md-6">
            <label>Product Quantity</label>
            <input type="text" name="p_qty" class ="form-control form-control-sm">
            </div>
            
        </div>
            <label for="customFile">Product Image</label>
            <div class="custom-file md-3">
            <input type="file" name="uploadFile"  class="custom-file-input" id="customFile">
            <label class="custom-file-lable" for="customFile">Choose File</label>
            </div>
            <button type ="submit" name = "submit" class="btn btn-sm text-white shadow">Add Item</button>
        </form>
        </div>
        <script>
        
        </script>
</div>

    </div>


</body>
</html>
<?php
if(isset($_POST['submit']))
{
    $p_qty = $_POST['p_qty'];
    $p_code = $_POST['p_code'];
    $p_price = $_POST['p_price'];
    $p_name = $_POST['p_name'];
    $p_cost = $_POST['p_cost'];
    $uploadFile = $_FILES['uploadFile']['name'];
    $tmpname = $_FILES['uploadFile']['tmp_name'];
    $folder ="images/".$uploadFile;
    move_uploaded_file($tmpname, $folder);

    if( $p_qty !="" && $p_code !="" && $p_price !="" && $p_name !="" 
    && $p_cost !="" && $folder !="")
    {
        $sql ="INSERT INTO `tbl_item`(`itemID`, `Description`, `Cost Price`, `Quantity`, `Sell Price`) 
        VALUES ('$p_code','$p_name','$p_cost','$p_qty','$p_price')";
        $conn->query($sql);
        $isql = "INSERT INTO `products`(`itemID`, `image`) VALUES ('$p_code','$folder')";
        $conn->query($isql);
        
        echo '<script>alert("Upload Done")</script>'; 

    }
    else
    {
        echo '<script>alert("Could not upload picture.")</script>'; 
    }




}
?>
