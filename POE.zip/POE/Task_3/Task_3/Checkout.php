<?php
    session_start();
    include 'DBConn.php';    

?>

<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shopping Cart</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="cart.css">

 
</head>
<body>
    <div class = "topnav">
         <a  href="addToCart.php" name="shopping_cart" class="active" data-toggle="popover" data-placement="top">Cart</a>
         <a href="logout.php">Logout</a>
    </div>
<div >
       <h1><?php  
                echo '<h1>Welcome to Hair ministry online store - '.$_SESSION["user"].'</h1>';  
                ?> </h1>
                </br>
                
                </div>
        </br>
        </br>
        </br>
        
</div>

    <div class="container" style="width: 65%">
        <h2>Shopping Cart</h2>
      
    </div>

</body>
</html>
