<?php

require_once('DBConn.php');
session_start();  
include'createTable.php';
if(isset($_POST['btnReg']))
{

     $username = mysqli_real_escape_string($conn, $_POST['username']);
     $lastname = mysqli_real_escape_string($conn,$_POST['lastname']);
     $email =  mysqli_real_escape_string($conn,$_POST['email']);
     $password = mysqli_real_escape_string($conn,$_POST['password']); 
     $cpassword = mysqli_real_escape_string($conn,$_POST['cpassword']);
     if(empty($username) || empty($lastname) || empty($email) || empty($password) || empty($cpassword))
     {
         echo '<script>alert("Both Fields are required")</script>';
     }
     else

    {
        $pass= md5($password);
        if($password == $cpassword)
        {
            $pass= md5($password);
            $query ="INSERT INTO `tbl_user`(`FName`, `LName`, `Email`, `Password`) "."VALUES 
            ('$username','$lastname','$email','$pass')";
            $result = mysqli_query($conn,$query);
            if(mysqli_query($conn, $query))  
           {  extract($_REQUEST);
            
               echo '<script>alert("Registration Done")</script>'; 
               header("Location: login.php"); 
           }
        }
    } 
    
       
        
       
        
          
       
      
      
  
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stle.css">
</head>
<body>
</div>    
                  
                <div class="container">
        <form action="" method="POST" class ="login-email">
            <p class ="login-text" style="font-size: 2rem; font-weight:800;">User Registration</p>
            <div class ="input-group">
                <input type="text" placeholder="Username" name ="username" autocomplete="off"  required>
            </div>
            <div class ="input-group">
                <input type="text" placeholder="Lastname" name ="lastname" autocomplete="off" required>
            </div>
            <div class ="input-group">
                <input type="email" placeholder="Email" name ="email" autocomplete="off" required>
            </div>
            <div class ="input-group">
                <input type="password" placeholder="Password" name ="password" autocomplete="off" required>
            </div>
            <div class ="input-group">
                <input type="password" placeholder="Confirm Password" name ="cpassword" autocomplete="off" required>
            </div>
            <div class ="input-group">
                <button  type = "submit" name="btnReg" class = "btn">Register</button>
            </div>
            <p class = "login-register-text">Have an account? <a href="login.php">Login Here</a>.</p>
            </form>  
                 
           </div>    
</body>
</html>