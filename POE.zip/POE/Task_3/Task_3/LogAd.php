<?php  
  require_once('DBConn.php');
 session_start(); 
 $error=0; 
   
 if(isset($_POST["btnLogin"]))  
 {  
    if(empty($_POST["user"]) && empty($_POST["pass"]))
    {
        echo'<script>alter("Please make sure all fields are filled")</script>';
    }
    else
    {
        $username = mysqli_real_escape_string($conn, $_POST["user"]);  
        $password = mysqli_real_escape_string($conn, $_POST["pass"]); 
        $query ="SELECT * FROM `admin` WHERE name = '$username' AND password  = '$password'"; //table = user
        $results = mysqli_query($conn,$query);
        if( $row = mysqli_fetch_assoc($results))
        {
            $_SESSION['user'] = $username; 
            
            header("Location: Add Item.php"); // redirecting to other page
            echo '<script>alert("Welcome")</script>';
          
        }
        else
        {
            echo '<script>alert("Wrong User Details")</script>';
        }
      }  
 }  
 ?>  
 <!DOCTYPE html>  
 <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stle.css">
</head> 
      <body>  
                
    <div class="container">
   
   <form action="" method ="POST" class ="login-email">
       <p class ="login-text" style="font-size: 2rem; font-weight:800;">Admin Login</p>
       </br>
         <p class ="login-text"></p>
       <div class ="input-group">
           <input type="text" placeholder="Username" name ="user" autocomplete="off"  required>
       </div> 
       <div class ="input-group">
           <input type="password" placeholder="Password" name="pass" autocomplete="off" required>
       </div>
       <div class ="input-group">
           <button type = "submit" name="btnLogin" class = "btn">Login</button>
       </div>
       
   </form>
    </div>  
           
      </body>  
 </html>  