<!--
//Reference List:
//Reece Wanwig
-->
<?php
        $ErrorMsgs = array();
        
 
        // create connection
        $conn = mysqli_connect("localhost", "root", "", "test");
 
         // Check connection
     
        if(!$conn)
        {
            $ErrorMsgs[] = "Database tatus: Connection failed";
        }
       
   
?>
