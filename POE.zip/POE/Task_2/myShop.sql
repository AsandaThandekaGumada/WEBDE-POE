-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2021 at 06:15 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `itemID` text NOT NULL,
  `image` varchar(225) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `itemID`, `image`) VALUES
(1, 'CANT5', '13661-cantu-scalp-treatment-180ml.jpg'),
(2, 'ANTI1', 'AuntJackie\'sPerfectType4Kit.jpg'),
(3, 'NATC4', 'NativeChildAntibreakage&Transitioningcombo.jpg'),
(4, 'NATC1', 'NativeChild-KidsStartercombo.jpg'),
(5, 'NATC2', 'NativeChild-LOCcombo.jpg'),
(6, 'NATC3', 'Native Child - Shampoo and Conditioner combo.jpg'),
(7, 'CANT1 ', 'cantu-curl-activator-cream-355ml-13459663814713_202x.jpg'),
(8, 'CANT2', 'cantu-edge-stay-gel-64g-13610225696825_202x.jpg'),
(9, 'CANT3', 'cantu-grow-strong-173g-13459659685945_202x.jpg'),
(10, 'CANT4', 'cantu-repair-cream-shea-butter-453g-13511271022649_202x.jpg'),
(11, 'CANT6', 'cantu-strengthening-styling-gel-524g-13459664666681_202x.jpg'),
(12, 'ANTI3', 'aunt-jackie-s-perfect-911-damage-repair-kit-28758267363478_2048x2048.jpg'),
(13, 'ANTI4', 'aunt-jackie-s-perfect-intense-define-bundle-28758192816278_2048x2048.jpg'),
(14, 'ANTI5', 'aunt-jackie-s-perfect-hydrate-your-curls-kit-large-28758572826774_2048x2048.jpg'),
(15, 'ANTI6', 'aunt-jackie-s-perfect-wash-n-go-kit-28758389358742_2048x2048.jpg'),
(16, 'SHEA1', 'NaturalDirectSheaButter.jpg'),
(17, 'HAIRK', 'Curly Care - Natural Hair Products - Starter Kit.jpg'),
(18, 'CROCH', '741-crochet-needle-18876604055702_202x.jpg'),
(19, 'DARL2', '2231-1-darling-one-million-braid-20-13376284164153_216x.jpg'),
(20, 'DARL1', '15480-1-darling-passion-twist-30-19009231421590_216x.jpg'),
(21, 'DARL3', '14521-1-darling-marley-kinky-braid-14-20086467428502_216x.jpg'),
(22, 'DARL4', '14209-darling-one-million-braid-20-1-value-pack-20086330884246_216x.jpg'),
(23, 'DARL5', '16258-darling-pre-curled-braid-19-1-28191906431126_216x.jpg'),
(24, 'AFRO1', '13216-afrotex-afro-classic-16-1-13439910281273_216x.jpg'),
(25, 'AFRO2', '16312-1-afrotex-yaky-braid-24-value-pack-28192529842326_216x.jpg'),
(26, 'AFRO3', '14452-hair-nova-afro-phondo-1-large-27970357854358_216x.jpg'),
(27, 'AFRO4', '10636-afrotex-eazy-braid-27-1-27-19929914900630_216x.jpg'),
(28, 'BEAU1', '13421-beau-diva-straight-8-10-12-natural-13383893745721_216x.jpg'),
(29, 'BEAU2', '13423-beau-diva-straight-12-14-16-natural-19931448213654_216x.jpg'),
(30, 'BEAU3', '13424-beau-diva-straight-14-16-18-natural-19931472953494_216x.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `Customer_ID` int(10) NOT NULL,
  `ID` int(11) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Contact_num` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_item`
--

CREATE TABLE `tbl_item` (
  `itemID` text NOT NULL,
  `Description` text NOT NULL,
  `Cost Price` decimal(10,0) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Sell Price` decimal(10,0) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_item`
--

INSERT INTO `tbl_item` (`itemID`, `Description`, `Cost Price`, `Quantity`, `Sell Price`) VALUES
('ANTI1', 'Aunt Jackie\'s Perfect Type 4 Kit', '266', 100, '326'),
('NATC4', 'Native Child - Anti breakage & Transitioning combo', '289', 369, '350'),
('NATC1', 'Native Child - Kids Starter Combo', '250', 51, '310'),
('NATC2', 'Native Child - LOC Combo', '150', 20, '210'),
('NATC3', 'Native Child - Shampoo and Conditioner Combo', '100', 9, '160'),
('CANT1', 'Cantu Curl Activator Cream', '50', 150, '90'),
('CANT2', 'Cantu Edge Stay Gel', '77', 53, '104'),
('CANT3', 'Cantu Grow Strong', '85', 20, '126'),
('CANT4', 'Cantu Repair Cream Shea Butter', '66', 101, '126'),
('CANT6', 'Cantu Strengthening Styling gel', '91', 21, '181'),
('ANTI3\r\n ', 'Aunt Jackie\'s Perfect 911 Damage Repair Kit', '420', 33, '470'),
('ANTI4\r\n ', 'Aunt Jackie\'s Perfect Intense Define Bundle', '307', 50, '367'),
('ANTI5\r\n ', 'Aunt Jackie\'s Perfect Hydrate Your Curls Kit Large', '300', 100, '360'),
('ANTI6', 'Aunt Jackie\'s Perfect Wash n’ Go Kit', '220', 132, '280'),
('CANT5', 'Cantu Scalp Treament', '200', 200, '260'),
('SHEA1', 'Nature Direct Shea Butter 1Kg', '275', 150, '300'),
('HAIRK', 'Curly Care - Natural Hair Products - StarterKit', '620', 50, '650'),
('CROCH', 'Crochet Braid Needle', '10', 500, '16'),
('DARL1', 'DARLING HAIR PIECES Darling Passion Twist', '30', 90, '150'),
('DARL2', 'DARLING HAIR PIECES Darling One Million Braid 20', '25', 10, '26'),
('DARL3', 'Darling Marley Kinky Braid 14', '60', 150, '65'),
('DARL4', 'HAIR PIECES Darling One Million Braid 20', '50', 50, '51'),
('DARL5', 'Darling Pre-Curled Braid 19\" #1', '210', 120, '220'),
('AFRO1', 'Afrotex Afro Classic 16', '76', 35, '80'),
('AFRO2', 'Afrotex Yaky Braid 24\" Value Pack', '24', 50, '30'),
('AFRO3', ' AFRO3,Hair Nova Afro Phondo #1 Large', '95', 56, '100'),
('AFRO4', 'Afrotex Eazy Braid 27\" Ombre', '21', 0, '30'),
('BEAU1', 'Beau Diva Straight 8\"+10\"+12\" #Natural', '495', 1000, '500'),
('BEAU2', 'Beau Diva Straight 12\"+14\"+16\" #Natural', '780', 150, '800'),
('BEAU3', 'Beau Diva Straight 14\"+16\"+18\" #Natural', '950', 100, '1000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `Order_ID` int(10) NOT NULL,
  `Customer_ID` int(11) NOT NULL,
  `itemID` varchar(5) NOT NULL,
  `Delivery Price` decimal(10,0) NOT NULL,
  `Total_Price` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `ID` int(11) NOT NULL,
  `FName` text NOT NULL,
  `LName` text NOT NULL,
  `Email` text NOT NULL,
  `Password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` ( `FName`, `LName`, `Email`, `Password`) VALUES
( 'asa', 'asa', 'asa@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( ' David Cody', 'Kora', 'DCK@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( ' Asa', 'asa', 'asa@asa.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( ' Reba', 'Roommate', 'RR@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Aphiwe', 'Jas', 'AJ@mail.com', '8c8d357b5e872bbacd45197626bd5759'),
( 'Sindiswa', 'Kojana', 'SK@mail.com', 'f542a15207506cde02a13e648815aa57'),
( 'Nombulelo', 'Kwatlhaji', 'nkwahlaji@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Porshia', 'Ndamane', 'PNdamane@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Tercia', 'Ndamane', 'Tercia122@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Avuzwa', 'Gumada', 'avg@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Lungile', 'Gumada', 'lg@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Neliswa', 'Gumada', 'neliswa@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Asanda', 'Gumada', 'asa@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Cole', 'Mile', 'miles@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Miles', 'Williams', 'MWilliams@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
('Zunaid', 'Blom', 'Zunaid@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Arthur', 'Chirwa', 'Flex@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Delano', 'Blom', 'DBlom@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Abongile', 'Maliwa', 'AgoMaliwa@mail.com', '457391c9c82bfdcbb4947278c0401e41\n')
( 'Thabiso', 'Ezioko', 'thandi@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Boitumelo', 'Selekedi', 'tumiSelekedi@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Stuard', 'Jafta', 'jafta@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Eunice', 'Gumada', 'Eunice@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Delia', 'Shorore', 'Shorore@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Martin', 'Steward', 'mSteward@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Alexis', 'Stain', 'AStain@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Jerton', 'Louw', 'JLouw@mail.com', '2c45c8a1c0cd36bbc45044e34dd062d2\n'),
( 'Asa', 'asa', 'asa@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( 'Mapehli', 'Dineo', 'MD@mail.com', '1ebc77995fb9e45db9f357f77472614b\n'),
( ' David Cody', 'Kora', 'DCK@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( ' Reba', 'Roommate', 'RR@mail.com', '457391c9c82bfdcbb4947278c0401e41\n'),
( ' Aphiwe', 'Jas', 'AJ@mail.com', '8c8d357b5e872bbacd45197626bd5759\n');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`Customer_ID`),
  ADD KEY `ID` (`ID`);

--
-- Indexes for table `tbl_item`
--
ALTER TABLE `tbl_item`
  ADD PRIMARY KEY (`itemID`(5));

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`Order_ID`),
  ADD KEY `Customer_ID` (`Customer_ID`,`itemID`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `Customer_ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `Order_ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD CONSTRAINT `tbl_customer_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `tbl_user` (`ID`);

--
-- Constraints for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD CONSTRAINT `tbl_order_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `tbl_customer` (`Customer_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
