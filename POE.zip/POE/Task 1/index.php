<?php  
   session_start(); 
 if(!isset($_SESSION["user"]))  
 {  
      header("location:login.php?action=login");  
 }  
 ?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Hair Ministries User Page</title>
</head>
<body >
    <div > 
   
   <form action="" method ="POST" class ="">
       <div class = "topnav">
         <a  href="addToCart.php" name="shopping_cart" class="active" data-toggle="popover" data-placement="top">Cart</a>
         <a href="logout.php">Logout</a>
       </div>
</br>
</br>
</br>
        </br>
        </br>
        </br>
        </br>
        </br>
        </br>
        </br>
        </br>

       <div c>
       <h1>
           <?php  
                echo '<h1>Welcome - '.$_SESSION["user"].'</h1>';  
                ?> </h1>
                </br>
                <h2>Click button below to view products</h2>
                </div>
        </br>
        </br>
        </br>
        
</div>

        <div >
            <button type = "submit" name="btnView" class ="btn">Show Items</button>
            <?php
        if (isset($_POST['btnView']))
        {
            include_once 'fetchArray.php';
        }
        ?>
        </div>
    </br>
       
   </form>  

    </div>
   
</body>
</html>


