<!--
//Reference List:
//Reece Wanwig
-->
<?php

    
    //create connnection
    $conn = mysqli_connect('localhost','root', '','test');
   //check connectio
   if($conn -> connect_error)
   {
       die("Database tatus: Connection failed: " .$conn->connect_error);
   }
   else
   {
    echo'<script>alter("Succefully Connected")</script>';
       
   }
     
   
?>
