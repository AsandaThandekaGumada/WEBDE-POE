 
<?php
require_once('DBConn.php');

$Exists = mysqli_query($conn,"select 1 from tbl_user");

if($Exists !== FALSE)
{
   $delete= mysqli_query($conn,"DROP TABLE tbl_user");
   $sql = "CREATE TABLE  tbl_user(
    ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    FName TEXT NOT NULL,
    LName TEXT NOT NULL,
    Email TEXT NOT NULL,
    Password TEXT NOT NULL);";
    $result = mysqli_query($conn, $sql);

   echo '<script>alert("Table dropped, recreated and data stored successfully")</script>';
 

}
else
{
    $sql = "CREATE TABLE  tbl_user(
        ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        FName TEXT NOT NULL,
        LName TEXT NOT NULL,
        Email TEXT NOT NULL,
        Password TEXT NOT NULL);";
        $result = mysqli_query($conn, $sql) or die("Error");
       
       echo '<script>alert("Table created and data stored successfully")</script>';
    

         
}
    
 ?>
 