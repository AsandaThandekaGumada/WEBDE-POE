<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Cart</title>
    <body >
    <div > 
   
   <form action="" method ="POST" class ="">
       <div class = "topnav">
         <a  href="index.php" name="shopping_cart" class="active" data-toggle="popover" data-placement="top">Shop</a>
         <a href="logout.php">Logout</a>
       </div>  
             



    <h2>Item Selected</h2>
    <?php
    session_start();
    include "fetchArray.php";
        var_dump($_SESSION('cart'))

    ?>
    <button type = "submit" name="btnBack" class ="btn"> <a href="index.php">Back</a></button>
    
   
</head>
<body>
    
</body>
</html>