<?php  
  require_once('DBConn.php');
 session_start();  
 if(isset($_SESSION["user"]))  
 {  
      header("location:index.php");  
 }  
 
 if(isset($_POST['btnReg']))
{
    include'createTable.php';
     $username = mysqli_real_escape_string($conn, $_POST['username']);
     $lastname = mysqli_real_escape_string($conn,$_POST['lastname']);
     $email =  mysqli_real_escape_string($conn,$_POST['email']);
     $password = mysqli_real_escape_string($conn,$_POST['password']); 
     $cpassword = mysqli_real_escape_string($conn,$_POST['cpassword']);
     if(empty($username) || empty($lastname) || empty($email) || empty($password) || empty($cpassword))
     {
         echo '<script>alert("Both Fields are required")</script>';
     }
     if($password == $cpassword)
     {
         $pass= md5($password);
            
        $file = fopen("userData.txt", "a");
        fwrite($file, "");
        fwrite($file, $username . ",");
        fwrite($file, "");
        fwrite($file, $lastname . ",");
        fwrite($file, "");
        fwrite($file, $email . ",");
        fwrite($file, "");
        fwrite($file, $pass. "\n");
        fclose($file);
        
        $file = fopen("userData.txt", "r");
        while(!feof($file))
        {
            $getText = fgets($file);
            $explodeLine = explode(",",$getText);
            list($username,$lastname,$email,$password) = $explodeLine;
    
            $sql = "INSERT INTO `tbl_user`( `Fname`, `Lname`, `Email`, `Password`) 
            VALUES ('$username','$lastname','$email','$password')";
             mysqli_query($conn,$sql);
       }
       fclose($file);   
    
        if(mysqli_query($conn, $sql))  
        {  extract($_REQUEST);
         
            echo '<script>alert("Registration Done")</script>'; 
            header("location: login.php?action=login"); 
        }
     
     }
     else
     {
         echo '<script>alert("User could not be registered"</script>';
     }
 }
 if(isset($_POST["btnLogin"]))  
 {  
    if(empty($_POST["user"]) && empty($_POST["pass"]))
    {
        echo'<script>alter("Please make sure all fields are filled")</script>';
    }
    else
    {
        $username = mysqli_real_escape_string($conn, $_POST["user"]);  
        $password = mysqli_real_escape_string($conn, $_POST["pass"]);  
        $password = md5($password); 
        $query ="SELECT * FROM `tbl_user` WHERE FName = '$username' AND Password  = '$password'"; //table = tbl_user
        $results = mysqli_query($conn,$query);
        if($row = mysqli_fetch_assoc($results))
        {
            $_SESSION['user'] = $username; 
            header("Location: index.php"); // redirecting to other page
            echo '<script>alert("Welcome")</script>';
               
            
        }
    
        else
        {
            
            echo '<script>alert("Wrong User Details")</script>';
    
        }
      }  
 }  
 ?>  
 <!DOCTYPE html>  
 <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stle.css">
</head> 
      <body>  
           <br /><br />    
              
                <br />  
                <?php  
                if(isset($_GET["action"]) == "login")  
                {  
                ?> 
                 
                
    <div class="container">
   
   <form action="" method ="POST" class ="login-email">
       <p class ="login-text" style="font-size: 2rem; font-weight:800;">Login</p>
       <div class ="input-group">
           <input type="text" placeholder="Username" name ="user" autocomplete="off"  required>
       </div> 
       <div class ="input-group">
           <input type="password" placeholder="Password" name="pass" autocomplete="off" required>
       </div>
       <div class ="input-group">
           <button type = "submit" name="btnLogin" class = "btn">Login</button>
       </div>
       <p class = "login-register-text">Don't have an account? <a href="login.php">Register Here</a>.</p>
       
   </form>
</div>  
                <?php       
                }  
                else  
                {  
                ?>  
                  
                <div class="container">
        <form action="" method="POST" class ="login-email">
            <p class ="login-text" style="font-size: 2rem; font-weight:800;">User Registration</p>
            <div class ="input-group">
                <input type="text" placeholder="Username" name ="username" autocomplete="off"  required>
            </div>
            <div class ="input-group">
                <input type="text" placeholder="Lastname" name ="lastname" autocomplete="off" required>
            </div>
            <div class ="input-group">
                <input type="email" placeholder="Email" name ="email" autocomplete="off" required>
            </div>
            <div class ="input-group">
                <input type="password" placeholder="Password" name ="password" autocomplete="off" required>
            </div>
            <div class ="input-group">
                <input type="password" placeholder="Confirm Password" name ="cpassword" autocomplete="off" required>
            </div>
            <div class ="input-group">
                <button  type = "submit" name="btnReg" class = "btn">Register</button>
            </div>
            <p class = "login-register-text">Have an account? <a href="login.php?action=login">Login Here</a>.</p>
            </form>  
                <?php  
                }  
                ?>  
           </div>  
      </body>  
 </html>  